<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DispatchMailWithoutEditingController extends Controller
{
    public function dispatchMail(Request $request){
        //
    }

}
